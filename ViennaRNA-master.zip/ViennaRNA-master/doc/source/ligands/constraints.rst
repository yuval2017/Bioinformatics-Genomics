Incorporating Ligands Binding to Specific Sequence/Structure Motifs
===================================================================

Ligand binding to specific hairpin/interior loop like motifs using
the :doc:`/grammar/constraints/soft` feature.

.. doxygengroup:: constraints_ligand
    :no-title:
