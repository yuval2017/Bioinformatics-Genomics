Local (sliding window) Partition Function and Equilibrium Probabilities
=======================================================================

Scanning version using a sliding window approach to compute equilibrium
probabilities.

.. doxygengroup:: part_func_window
    :no-title:
