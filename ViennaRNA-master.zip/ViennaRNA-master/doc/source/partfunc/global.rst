Global Partition Function and Equilibrium Probabilities
=======================================================

Variations of the global partition function algorithm.

We provide implementations of the global partition function algorithm for

* Single sequences,
* Multiple sequence alignments (MSA), and
* RNA-RNA hybrids

.. doxygengroup:: part_func_global
    :no-title:
