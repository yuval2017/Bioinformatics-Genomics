Deprecated Interface for Local (Sliding Window) Partition Function Computation
==============================================================================

.. doxygengroup:: part_func_window_deprecated
    :no-title:
