Pair Table Representation of Secondary Structures
=================================================

.. doxygengroup:: struct_utils_pair_table
    :no-title:
