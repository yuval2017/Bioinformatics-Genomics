Washington University Secondary Structure (WUSS) notation
=========================================================

.. doxygengroup:: struct_utils_wuss
    :no-title:
