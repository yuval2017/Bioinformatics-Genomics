Pair List Representation of Secondary Structures
================================================

.. doxygengroup:: struct_utils_plist
    :no-title:
