Helix List Representation of Secondary Structures
=================================================

.. doxygengroup:: struct_utils_helix_list
    :content-only:
