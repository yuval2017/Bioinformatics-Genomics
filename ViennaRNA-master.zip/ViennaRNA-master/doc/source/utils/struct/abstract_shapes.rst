Abstract Shapes Representation of Secondary Structures
======================================================

.. doxygengroup:: struct_utils_abstract_shapes
    :no-title:
