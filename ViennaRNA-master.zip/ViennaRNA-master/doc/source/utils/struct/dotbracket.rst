Dot-Bracket Notation of Secondary Structures
============================================

.. doxygengroup:: struct_utils_dot_bracket
    :no-title:
