Deprecated Interface for Secondary Structure Utilities
======================================================

.. doxygengroup:: struct_utils_deprecated
    :no-title:
