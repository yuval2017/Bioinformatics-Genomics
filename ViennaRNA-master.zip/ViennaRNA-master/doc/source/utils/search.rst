Search Algorithms
=================

Implementations of various search algorithms to detect strings of objects
within other strings of objects.

.. doxygengroup:: search_utils
    :no-title:
