Buffers
=======

Functions that provide dynamically buffered stream-like data structures.

.. doxygengroup:: buffer_utils
    :no-title:
