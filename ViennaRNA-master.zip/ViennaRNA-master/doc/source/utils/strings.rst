(Nucleic Acid Sequence) String Utilitites
=========================================

Functions to parse, convert, manipulate, create, and compare
(nucleic acid sequence) strings.

.. doxygengroup:: string_utils
    :no-title:
