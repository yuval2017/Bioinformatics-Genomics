Deprecated Interface for Plotting Utilities
===========================================

.. doxygengroup:: plotting_utils_deprecated
    :no-title:
