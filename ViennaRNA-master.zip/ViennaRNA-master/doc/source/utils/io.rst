Files and I/O
=============

.. toctree::
   :maxdepth: 1
   :caption: Specialized Modules:

   io/file_formats
   io/file_formats_msa
   io/commands

.. doxygengroup:: file_utils
    :no-title:
