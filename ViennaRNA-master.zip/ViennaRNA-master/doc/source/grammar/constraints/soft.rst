Soft Constraints
================

Functions and data structures for secondary structure soft constraints.

Soft-constraints are used to change position specific contributions
in the recursions by adding bonuses/penalties in form of pseudo free energies
to certain loop configurations.

.. doxygengroup:: soft_constraints
    :no-title:

