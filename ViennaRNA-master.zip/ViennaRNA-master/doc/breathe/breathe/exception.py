class BreatheError(Exception):
    pass
