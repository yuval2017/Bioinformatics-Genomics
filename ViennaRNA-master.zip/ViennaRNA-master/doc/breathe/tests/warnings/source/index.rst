
Test Breathe Warnings
=====================

This Sphinx instance is designed to call Breathe in every single incorrect way
in order to test that the warnings work without crashing the build process.

.. toctree::
   :maxdepth: 2

   class
   function
   group
   define



