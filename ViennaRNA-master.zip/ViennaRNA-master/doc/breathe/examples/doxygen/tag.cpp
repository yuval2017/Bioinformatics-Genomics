/*! A class that is inherited from the external class Test13.
*/

class Tag : public Test13
{
  public:
    /*! an overloaded member. */
    void example();
};
