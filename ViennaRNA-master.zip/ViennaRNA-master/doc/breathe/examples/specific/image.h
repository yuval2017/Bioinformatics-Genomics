/**
* This is a class with an image in the description. It renders like this:
*
* \image HTML imageExample.png
*
* Breathe & Sphinx should automatically copy the image from the doxygen output directory into the
* _images folder of the Sphinx output.
*/
class ImageClass {};
