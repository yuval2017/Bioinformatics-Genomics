
class Out
{
public:

    //! \b Constructor \a for Out object
    Out() {}

    //! \a Destructor \b for Out object
    ~Out() {}

};

