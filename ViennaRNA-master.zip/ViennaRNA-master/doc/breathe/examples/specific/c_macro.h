
#define A_C_MACRO "hello world"
#define ANOTHER_C_MACRO(name) "hello" name
