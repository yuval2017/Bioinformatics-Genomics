
//! \brief class outside of namespace
class AutoClassTest {

    //! \brief non-namespaced class function
    void member() {};

    //! \brief non-namespaced class other function
    void anotherMember() {};
};


