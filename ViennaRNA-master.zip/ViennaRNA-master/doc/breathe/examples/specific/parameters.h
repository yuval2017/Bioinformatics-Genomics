
/*! My function */
int f(int a, float b, int* c, int (*p)[3]);

class MyClass {};

int g(MyClass a, MyClass* b);

