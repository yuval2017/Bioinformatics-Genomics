# License

```{include} ../../../../license.txt
```
